# NSE Options Strategy Dashboard
This dashboard analyzes option data using Delta Crossover, OI Buildup, PCR & Max Pain strategies.